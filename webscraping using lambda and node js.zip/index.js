var cheerio = require('cheerio');
var request = require('request');
exports.handler = (event,context,callback) => {
    var url = event.url;
    var array = new Array('dollar','dollartitle','dollardesc','dollarkwd','dollarogTitle','dollarogImage','dollarogkeywords','dollarimages');
    console.log('debug1');
    //make a new request to the URL provided in the HTTP POST request
    request(url, function (error, response, responseHtml) {
        var resObj = {};
        
        //if there was an error
        if (error) {
            context.succeed(JSON.stringify({error: 'There was an error of some kind'}));
            return;
        }

        //create the cheerio object
        resObj = {},
            //set a reference to the document that came back
            array.dollar = cheerio.load(responseHtml),
            //create a reference to the meta elements
            array.dollartitle = array.dollar('head title').text(),
            array.dollardesc = array.dollar('meta[name="description"]').attr('content'),
            array.dollarkwd = array.dollar('meta[name="keywords"]').attr('content'),
            array.dollarogTitle = array.dollar('meta[property="og:title"]').attr('content'),
            array.dollarogImage = array.dollar('meta[property="og:image"]').attr('content'),
            array.dollarogkeywords = array.dollar('meta[property="og:keywords"]').attr('content'),
            array.dollarimages = array.dollar('img');

        if (array.dollartitle) {
            resObj.title = array.dollartitle;
        }

        if (array.dollardesc) {
            resObj.description = array.dollardesc;
        }

        if (array.dollarkwd) {
            resObj.keywords = array.dollarkwd;
        }

        if (array.dollarogImage && array.dollarogImage.length){
            resObj.ogImage = array.dollarogImage;
        }

        if (array.dollarogTitle && array.dollarogTitle.length){
            resObj.ogTitle = array.dollarogTitle;
        }

        if (array.dollarogkeywords && array.dollarogkeywords.length){
            resObj.ogkeywords = array.dollarogkeywords;
        }

        if (array.dollarimages && array.dollarimages.length){
            resObj.images = [];

            for (var i = 0; i < array.dollarimages.length; i++) {
                resObj.images.push(array.ollar(array.dollarimages[i]).attr('src'));
            }
        }

        //send the response
        console.log(resObj);
        context.succeed(resObj);
    }) ;
};
